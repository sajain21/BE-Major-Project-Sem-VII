import "./styles.css";
import BarChart from "./components/react-chart-js/BarChart";
import LineChart from "./components/react-chart-js/LineChart";
import PieChart from "./components/react-chart-js/pieChart";
import { useState } from "react";
import { UserData, UserData1, piechart } from "./Data";

export default function App() {
  const [userData, setUserData] = useState({
    labels: UserData.map((data) => data.year),
    datasets: [
      {
        label: "Students Enrolled",
        data: UserData.map((data) => data.userGain),
        backgroundColor: [
          "#246be4",
          "#2b771d",
          "#c7830a",
          "#bf2a36",
          "#c865a6"
        ],
        borderColor: "#236ae2"
      }
    ]
  });
  const [userData1, setUserData1] = useState({
    labels: UserData1.map((data) => data.year),
    datasets: [
      {
        label: "Yearly Revenue",
        data: UserData1.map((data) => data.userGain),
        backgroundColor: [
          "#246be4",
          "#2b771d",
          "#c7830a",
          "#bf2a36",
          "#c865a6"
        ],
        borderColor: "#236ae2"
      }
    ]
  });

  const [pieChart, setUserData2] = useState({
    labels: piechart.map((data) => data.label),
    datasets: [
      {
        label: "Course Progress",
        data: piechart.map((data) => data.user),
        backgroundColor: [
          "#246be4",
          "#2b771d",
          "#c7830a",
          "#bf2a36",
          "#c865a6"
        ],
        borderColor: "#236ae2"
      }
    ]
  });

  return (
    <div className="App row">
      <div className="container custom-bg my-3 mx-2 col">
        <BarChart chartData={userData} />
      </div>
      <div className="container custom-bg my-3 mx-2 col">
        <LineChart chartData={userData1} />
      </div>
      <div className="container custom-bg pie my-3 mx-2 col">
        <PieChart chartData={pieChart} />
      </div>
    </div>
  );
}
