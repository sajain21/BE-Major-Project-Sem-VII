export const UserData = [
    {
      id: 1,
      year: 2016,
      userGain: 1180000,
      userLost: 823
    },
    {
      id: 2,
      year: 2017,
      userGain: 1220000,
      userLost: 723
    },
    {
      id: 3,
      year: 2018,
      userGain: 172000,
      userLost: 23
    },
    {
      id: 4,
      year: 2019,
      userGain: 281000,
      userLost: 323
    },
    {
      id: 5,
      year: 2020,
      userGain: 999999,
      userLost: 3
    }
  ];
  
  export const UserData1 = [
    {
      id: 1,
      year: 2016,
      userGain: 334,
      userLost: 823
    },
    {
      id: 2,
      year: 2017,
      userGain: 360,
      userLost: 723
    },
    {
      id: 3,
      year: 2018,
      userGain: 79,
      userLost: 23
    },
    {
      id: 4,
      year: 2019,
      userGain: 98,
      userLost: 323
    },
    {
      id: 5,
      year: 2020,
      userGain: 250,
      userLost: 3
    }
  ];

  export const piechart = [
    {
      id: 1,
      label: 'Not Started',
      user: 600,
      userLost: 823
    },
    {
      id: 2,
      label: '25% Completed',
      user: 1800,
      userGain: 1220000,
      userLost: 723
    },
    {
      id: 3,
      label: '50% Completed',
      user: 1250,
      userGain: 172000,
      userLost: 23
    },
    {
      id: 4,
      label: '75% Completed',
      user: 2500,
      userGain: 281000,
      userLost: 323
    },
    {
      id: 5,
      label: 'Completed',
      user: 5552,
      userGain: 999999,
      userLost: 3
    }
  ];